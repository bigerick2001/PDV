﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unimake.Business.DFe.Xml.NFe;

namespace Labs.Main.ReceitaFederal
{
	public class ConstrutorNFE
	{

	}
}
