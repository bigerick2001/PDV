﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Unimake.Unidanfe;
using Unimake.Unidanfe.Configurations;

namespace Labs.Main.ReceitaFederal
{
	public class DANFE
	{
		public static void ConfigsDANFE()
		{
			UnidanfeServices.ShowConfigurationScreen();
		}
		/// <summary>
		/// Gera o Arquivo de XML da nota na pasta NFe/Autorizadas
		/// </summary>
		/// <param name="fiscalXml">Xml da nota para gerar o arquivo</param>
		public static async void GerarArquivoXML_NotaFiscalXml_Async(NotaFiscalXml fiscalXml)
		{
			//
			if(Path.Exists(Path.Combine($"NFe/Autorizadas/NFCE-{fiscalXml.IDVenda}.xml"))) { Modais.MostrarInfo("O XML referente a venda selecionada já existe!"); return; }
			//
			string arq = Path.Combine($"NFe/Autorizadas/NFCE-{fiscalXml.IDVenda}.xml");
			//
			StreamWriter writer = File.CreateText(arq);
			await writer.WriteAsync(fiscalXml.XmlNota);
			await writer.FlushAsync();
			await writer.DisposeAsync();
			Modais.MostrarInfo("XML da nota gerado com sucesso no caminho (NFe/Autorizadas)");
		}
		/// <summary>
		/// Gera o Arquivo de XML da nota na pasta NFe/Autorizadas
		/// </summary>
		/// <param name="fiscalXml">Xml da nota para gerar o arquivo</param>
		public static void GerarArquivoXML_NotaFiscalXml(NotaFiscalXml fiscalXml)
		{
			//
			if (Path.Exists(Path.Combine($"NFe/Autorizadas/NFCE-{fiscalXml.IDVenda}.xml"))) { Modais.MostrarInfo("O XML referente a venda selecionada já existe!"); return; }
			//
			string arq = Path.Combine($"NFe/Autorizadas/NFCE-{fiscalXml.IDVenda}.xml");
			//
			StreamWriter writer = File.CreateText(arq);
			writer.Write(fiscalXml.XmlNota);
			writer.Flush();
			writer.Dispose();
			Modais.MostrarInfo("XML da nota gerado com sucesso no caminho (NFe/Autorizadas)");
			// Abre o explorer na pasta das notas
		}
		//
		public static void ImprimirDANFE_NFCE_NotaFiscalXml(NotaFiscalXml fiscalXml,int Copias = 1, bool Visualize = false, bool Imprimir = true)
		{
			//
			string arq = Path.Combine($"NFe/Temp/NFCE-{fiscalXml.IDVenda}.xml");
			//
			StreamWriter writer = File.CreateText(arq);
			writer.Write(fiscalXml.XmlNota);
			writer.Flush();
			//
			if(writer != null)
			{
				//
				var Config = new UnidanfeConfiguration
				{
					Arquivo = arq,
					Copias = Copias,
					Visualizar = Visualize,
					Imprimir = Imprimir,
					Impressora = LabsMainAppWPF.ImpressoraTermica
				};
				UnidanfeServices.Execute(Config);
				writer.Dispose();
			}
			File.Delete(arq);
		}
		//
		public static void ImprimirDANFE_NFCE_IDVenda(string IDVenda,int Copias = 1, bool Visualize = false, bool Imprimir = true)
		{
			//
			var Config = new UnidanfeConfiguration
			{
				Arquivo = $"NFe/Autorizadas/NFCE-{IDVenda}.xml",
				Copias = Copias,
				Visualizar = Visualize,
				Imprimir = Imprimir,
				Impressora = LabsMainAppWPF.ImpressoraTermica
			};
			UnidanfeServices.Execute(Config);
		}
		//
		public static void ImprimirDANFE_NFCE_Path(string Path,int Copias = 1, bool Visualize = false, bool Imprimir = true)
		{
			//
			var Config = new UnidanfeConfiguration
			{
				Arquivo = Path,
				Copias = Copias,
				Visualizar = Visualize,
				Imprimir = Imprimir,
				Impressora = LabsMainAppWPF.ImpressoraTermica
			};
			UnidanfeServices.Execute(Config);
		}
	}
}
