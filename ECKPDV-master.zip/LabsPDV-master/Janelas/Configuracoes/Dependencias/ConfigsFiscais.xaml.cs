﻿using Labs.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Unimake.Business.DFe.Servicos;
using Unimake.Business.DFe.Xml.ESocial;

namespace Labs.Janelas.Configuracoes.Dependencias
{
	/// <summary>
	/// Lógica interna para ConfigsFiscais.xaml
	/// </summary>
	public partial class ConfigsFiscais : Window
	{
		List<X509Certificate2> Certificados = new List<X509Certificate2>();
		public ConfigsFiscais()
		{
			InitializeComponent();
			Initialize();
		}
		//
		private void LoadCertificates()
		{ 
			//Carrega os Certificados Tanto da Máquina quanto do usuário local, (Caso o Certificado tenha sido instalado em um dos dois, até porque o sistema não vai adivinhar...)
			try
			{
				X509Store UserStore = new(StoreName.My, StoreLocation.CurrentUser);
				UserStore.Open(OpenFlags.ReadOnly);
				//
				foreach (X509Certificate2 cert in UserStore.Certificates)
				{
					Certificados.Add(cert);
					SeletorCertificadoComboBox.Items.Add(cert.Subject);
				}
				//
				X509Store MachineStore = new(StoreName.My, StoreLocation.LocalMachine);
				MachineStore.Open(OpenFlags.ReadOnly);
				//
				foreach (X509Certificate2 cert in MachineStore.Certificates)
				{
					if (!Certificados.Contains(cert))
					{ 
						Certificados.Add(cert);
						SeletorCertificadoComboBox.Items.Add(cert.Subject);
					}
				}
				//
				MachineStore.Close();
				UserStore.Close();
			}
			catch (Exception ex)
			{
				Modais.MostrarErro("Erro ao carregar certificados: " + ex.Message);
			}
		}
		//
		private void LoadCRTs()
		{
			//Não precisamos criar um indexador já que o próprio seletor cuidará do index selecionado
			foreach (CRT crt in Enum.GetValues<CRT>())
			{
				SeletorCRTComboBox.Items.Add(crt);
			}
			//
		}
		//
		private void LoadEstados() 
		{
			foreach (UFBrasil uf in Enum.GetValues<UFBrasil>())
			{
				SeletorEstadoComboBox.Items.Add(uf);
			}
		}
		//
		private void LoadAmbientes() 
		{
			foreach (TipoAmbiente amb in Enum.GetValues<TipoAmbiente>())
			{
				SeletorAmbienteComboBox.Items.Add(amb);
			}
		}
		//
		private void LoadConfigs()
		{
			if(LabsMain.ConfiguracoesFiscais != null)
			{
				var cfg = LabsMain.ConfiguracoesFiscais;
				for (int i = 0; i < Certificados.Count; i++) { if (Certificados[i].SerialNumber == cfg.CertificadoSerial) { SeletorCertificadoComboBox.SelectedIndex = i; }; }
				//
				foreach (CRT crt in SeletorCRTComboBox.Items) { if (cfg.CRT == Enum.GetName(crt)) { SeletorCRTComboBox.SelectedItem = crt; } }
				foreach (UFBrasil uf in SeletorEstadoComboBox.Items) { if(cfg.UnidadeFederal == Enum.GetName(uf)) { SeletorEstadoComboBox.SelectedItem = uf; } }
				foreach (TipoAmbiente ab in SeletorAmbienteComboBox.Items) { if(cfg.TipoAmbiente == Enum.GetName(ab)) { SeletorAmbienteComboBox.SelectedItem = ab;} }
				//
				CodMunicipioInput.Text = cfg.CodMunicipio;
				NomeMunicipioInput.Text = cfg.NomeMunicipio;
				InscricaoEstadualInput.Text = cfg.InscricaoEstadual;
				CodCSCHomoInput.Text = cfg.CodCSCHomologacao;
				CodCSCProdInput.Text = cfg.CodCSCProducao;

			}
		}
		//
		private void Initialize()
		{
			LoadCertificates();
			LoadCRTs();
			LoadEstados();
			LoadAmbientes();
			//
			LoadConfigs();
		}
		//
		private bool Verify()
		{

			if(SeletorCertificadoComboBox.SelectedIndex == -1) { Modais.MostrarAviso("Você deve selecionar um certificado digital"); return false; }
			//
			if(InscricaoEstadualInput.Text.IsNullOrEmpty() || !Utils.IsValidBarCode(InscricaoEstadualInput.Text)) { Modais.MostrarAviso("Formato de incrição estadual inválida!"); return false; }
			//
			if(CodMunicipioInput.Text.IsNullOrEmpty() || !Utils.IsValidBarCode(CodMunicipioInput.Text)) { Modais.MostrarAviso("Formato de código do município inválido!"); return false; }
			//
			if (NomeMunicipioInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve inserir o nome do município"); return false; }
			//
			if(SeletorEstadoComboBox.SelectedIndex == -1) { Modais.MostrarAviso("Você deve selecionar uma Unidade Federal!"); return false; }
			//
			if(SeletorCRTComboBox.SelectedIndex == -1) { Modais.MostrarAviso("Você deve selecionar um CRT"); return false; }
			//
			if(CodCSCHomoInput.Text.IsNullOrEmpty() || CodCSCProdInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve informar os códigos CSC de Produção e Homologação!"); return false; }
			//
			if (SeletorAmbienteComboBox.SelectedIndex == -1) { Modais.MostrarAviso("Você deve selecionar um ambiente"); return false; }
			return true;
			//
		}
		/// <summary>
		/// Salvamos e encriptamos os dados para a segurança do cliente
		/// </summary>
		private void SalvarConfigs()
		{
			//Primeiro Geramos o json contendo as informações que precisamos
			var cert = Certificados[SeletorCertificadoComboBox.SelectedIndex];
			ConfiguracoesFiscais cfg = new()
			{
				CertificadoSerial = cert.SerialNumber,
				CodMunicipio = CodMunicipioInput.Text,
				NomeMunicipio = NomeMunicipioInput.Text,
				InscricaoEstadual = InscricaoEstadualInput.Text,
				CRT = $"{SeletorCRTComboBox.SelectedItem}",
				CodCSCHomologacao = CodCSCHomoInput.Text,
				CodCSCProducao = CodCSCProdInput.Text,
				UnidadeFederal = $"{SeletorEstadoComboBox.SelectedItem}",
				TipoAmbiente = $"{SeletorAmbienteComboBox.SelectedItem}"
			};
			//
			var str = JsonManager.GetJsonFromThis(cfg);
			//Agora encriptamos e salvamos
			LabsCripto.Encript("G_DATA",str);
			//
			Modais.MostrarInfo("Informações Salvas com Sucesso!\nReinicie o sistema para que as alterações sejam aplicadas!");
		}
		//
		private void SalvarButton_Click(object sender, RoutedEventArgs e)
		{
			if (Verify()) { SalvarConfigs(); }
		}
		//
		private void SairButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}
	}
}
