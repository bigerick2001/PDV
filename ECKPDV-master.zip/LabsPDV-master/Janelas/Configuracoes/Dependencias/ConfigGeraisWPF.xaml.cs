﻿using Labs.Main;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Labs.Janelas.Configuracoes.Dependencias
{
	/// <summary>
	/// Lógica interna para ImpressorasConfigWPF.xaml
	/// </summary>
	public partial class ConfigGeraisWPF : Window
	{
		ConfiguracoesGerais newConfigs { get; set; } = new() { Endereco = new() };
		public ConfigGeraisWPF()
		{
			InitializeComponent();
		}

		public void CarregarConfigs()
		{
			//
			if(LabsMain.ConfiguracoesGerais != null!)
			{
				var c = LabsMain.ConfiguracoesGerais;
				NomeEmpresaInput.Text = c.NomeEmpresa;
				NomeTitularInput.Text = c.NomeTitularCNPJ;
				CNPJInput.Text = c.CNPJ;
				TelefoneInput.Text = c.Telefone;
				// Parte do Endereço
				if(c.Endereco != null)
				{
					CEPInput.Text = c.Endereco.Cep;
					BairroInput.Text = c.Endereco.Bairro;
					CidadeInput.Text = c.Endereco.Localidade;
					RuaLogInput.Text = c.Endereco.Logradouro;
					ComplementoInput.Text = c.Endereco.Complemento;

				}
			}
		}

		private void SalvarButton_Click(object sender, RoutedEventArgs e)
		{
			if (NomeEmpresaInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve informar o nome da Empresa!"); return; }
			if (NomeTitularInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve informar o nome do titular!"); return; }
			if (!Utils.IsValidBarCode(CNPJInput.Text)) { Modais.MostrarAviso("Você deve informarum CNPJ válido!"); return; }
			if (!Utils.IsValidBarCode(TelefoneInput.Text)) { Modais.MostrarAviso("Você deve informar um Telefone válido para contato!"); return; }
			//Parte do Endereço
			if (!Utils.IsValidBarCode(CEPInput.Text)) { Modais.MostrarAviso("Você deve informar um CEP válido!"); return; }
			if (BairroInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve informar o Bairro!"); return; }
			if (CidadeInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve informar a Cidade!"); return; }
			if (RuaLogInput.Text.IsNullOrEmpty()) { Modais.MostrarAviso("Você deve Informar a Rua!"); return; }
			// o Complemento é opcional
			//salvamos, já que passou por todos os testes :D
			newConfigs.NomeEmpresa = NomeEmpresaInput.Text;
			newConfigs.NomeTitularCNPJ = NomeTitularInput.Text;
			newConfigs.CNPJ = CNPJInput.Text;
			newConfigs.Telefone = TelefoneInput.Text;
			//Endereço
			newConfigs.Endereco.Cep = CEPInput.Text;
			newConfigs.Endereco.Bairro = BairroInput.Text;
			newConfigs.Endereco.Localidade = CidadeInput.Text;
			newConfigs.Endereco.Logradouro = RuaLogInput.Text;
			newConfigs.Endereco.Complemento = ComplementoInput.Text;
			//Salvamos o json encriptado
			string json = JsonManager.GetJsonFromThis(newConfigs);
			LabsCripto.Encript("CG_DATA", json);
			//
			Modais.MostrarInfo("Informações salvas com sucesso!\nReinicie o sistema para que as alterações sejam aplicadas.");
        }

		private void SairButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		private void ConfigsFiscaisButton_Click(object sender, RoutedEventArgs e)
		{
			LabsMain.IniciarDependencia<ConfigsFiscais>();
		}

		//
		private async void GetEnd()
		{
			if (!Utils.IsValidBarCode(CEPInput.Text)) { Modais.MostrarAviso("Insira um CEP Válido"); return; }
			var end = await new ViaCepClient().GetEnderecoAsync(CEPInput.Text);
			BairroInput.Text = end.Bairro;
			CidadeInput.Text = end.Localidade;
			RuaLogInput.Text = end.Logradouro;
			ComplementoInput.Text = end.Complemento;
			//
			newConfigs.Endereco = end;
		}
		//


		private void CEPInput_KeyUp(object sender, KeyEventArgs e)
		{
			//Aqui faz a pesquisa pelo cep
			if(sender == CEPInput)
			{
				if(e.Key == Key.Enter) { GetEnd(); }
			}
		}
	}
}
